import { Component } from '@angular/core';

@Component({
    selector: 'pp-spinner',
    templateUrl: './spinner.component.html',
    styleUrls: ['./spinner.component.scss']
})
export class PortfolioSpinner {
    constructor() { }
}