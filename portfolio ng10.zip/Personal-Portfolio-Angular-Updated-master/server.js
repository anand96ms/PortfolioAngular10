//import modules We need them to run Node.js server and send emails
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");

// create a new Express application instance 
const app = express();

//configure the Express middleware to accept CORS requests and parse request body into JSON
app.use(cors({origin: "*" }));
app.use(bodyParser.json());

//start application server on port 3000
app.listen(3000, (req, res) => {
  console.log("The server started on port 3000");
});


// define a sendmail endpoint, which will send emails and response with the corresponding status
// app.post("/sendmail", (req, res) => {
//   console.log("request came");
//   let user = req.body;
//   sendMail(user, (err, info) => {
//     if (err) {
//       console.log(err);
//       res.status(400);
//       res.send({ error: "Failed to send the email!" });
//     } else {
//       console.log("Thank you for your email!");
//       res.send(info);
//     }
//   });
// });
app.get('/',(res,res)=>{
    res.send('service running')
})
//the following lines of code to set configuration of Nodemailer
const sendMail = (user, callback) => {
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: "<sender email>",
        pass: "<password>"
      }
    }); 
  }